<?php

if ($telegramApi->getText() == "users_list_manage") {

    $users = $sql->table("users")->where('is_admin', 0)->get();
    $admins = $sql->table("users")->where('is_admin', 1)->get();

    $text = "تعداد ادمین ها : <b>" . count($admins) . "</b><br>";
    $text .= "تعداد کاربران : <b>" . count($users) . "</b><br>";
    $text .= "تعداد کل کاربران : <b>" . count($users) + count($admins) . "</b>";


    $reply_markup = [
        'inline_keyboard' => [
            [
                [
                    'text' => 'بازگشت به صفحه ی قبل',
                    'callback_data' => 'return_admin_panel_button',
                ],
                [
                    'text' => 'بازگشت به منوی اصلی',
                    'callback_data' => 'return_home_button',
                ],
            ],
        ],
    ];
    $telegramApi->sendMessage($text, $reply_markup, null, "HTML");
}